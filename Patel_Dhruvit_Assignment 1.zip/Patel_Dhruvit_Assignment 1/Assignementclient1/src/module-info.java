/**
 * 
 */
/**
 * 
 */
module first {
	requires java.desktop;
}