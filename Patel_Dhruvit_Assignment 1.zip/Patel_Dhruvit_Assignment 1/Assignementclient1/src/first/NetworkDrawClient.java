package first;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.awt.BasicStroke;

public class NetworkDrawClient extends JFrame {
	/**
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 * # Method                :NetworkDrawClient
	 * #
	 * # Method parameters     : sendCommand/connectToServer/retrieveAndDraw/clearCommands
	 * #
	 * # Method return         : Yes to server.
	 * #
	 * # Synopsis              : 
	 * #   
	 * #
	 * # Modifications         :
	 * #                            Date       Developer       Notes
	 * #                            24/1/24   Dhruvit         Initial method creation.
	 * #                            
	 * #
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 */
    private final JTextField serverAddressField = new JTextField("localhost", 20);// Server address 
    private final JTextField portField = new JTextField("12345", 5);//Port ID
    private final JTextField lineLengthField = new JTextField("10", 5);// Line Lenght Fixed to 10
    private final JButton connectButton = new JButton("Connect");//Connect Button
    private final JButton drawButton = new JButton("DRAW");//Draw Button
    private final JButton clearButton = new JButton("CLEAR");//clear Button
    private Socket socket; // Socket
    private PrintWriter out;//Out for command out
    private final DrawPanel drawPanel = new DrawPanel();//Draw Panel
    private final List<String> commandList = new ArrayList<>();//Commandlist array to store commands

    // Constructor to set up the UI and initialize components
    public NetworkDrawClient() {
        setTitle("Network Draw Client");
        setSize(900, 691);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Top panel for server address, port, and line length input
        JPanel topPanel = new JPanel();
        topPanel.setBounds(10, 5, 776, 31);
        topPanel.setLayout(null);
        // Adding labels and text fields to the top panel
        JLabel label = new JLabel("Server Address:");
        label.setBounds(29, 9, 95, 13);
        topPanel.add(label);
        serverAddressField.setBounds(123, 6, 115, 19);
        topPanel.add(serverAddressField);
        JLabel label_1 = new JLabel("Port:");
        label_1.setBounds(292, 9, 46, 13);
        topPanel.add(label_1);
        portField.setBounds(324, 6, 46, 19);
        topPanel.add(portField);
        JLabel label_2 = new JLabel("Line Length:");
        label_2.setBounds(380, 9, 78, 13);
        topPanel.add(label_2);
        lineLengthField.setBounds(455, 6, 61, 19);
        topPanel.add(lineLengthField);
        connectButton.setBounds(612, 5, 107, 21);
        topPanel.add(connectButton);

        // Panel for direction and control buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(75, 599, 653, 31);
        // Adding direction buttons to the panel
        String[] directions = {"UP RED", "DOWN BLUE", "LEFT GREEN", "RIGHT YELLOW"};
        for (String dir : directions) {
            JButton button = new JButton(dir);
            button.addActionListener(this::sendCommand);
            buttonPanel.add(button);
        }
        getContentPane().setLayout(null);

        // Adding panels and buttons to the content pane
        getContentPane().add(topPanel);
        getContentPane().add(buttonPanel);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        buttonPanel.add(drawButton);
        buttonPanel.add(clearButton);
        clearButton.addActionListener(e -> clearCommands());
        drawButton.addActionListener(e -> retrieveAndDraw());
        drawPanel.setBounds(10, 46, 866, 552);
        getContentPane().add(drawPanel);
        drawPanel.setBackground(Color.BLACK);
        drawPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

        // Adding action listener for the connect button
        connectButton.addActionListener(e -> connectToServer());

        setVisible(true);
    }

    /**
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 * # Method                :NetworkDrawClient
	 * #
	 * # Method parameters     : sendCommand
	 * #
	 * # Method return         : Yes to server.
	 * #
	 * # Synopsis              : 
	 * #   
	 * #
	 * # Modifications         :
	 * #                            Date       Developer       Notes
	 * #                            24/1/24   Dhruvit         Initial method creation.
	 * #                            
	 * #
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 */
    private void sendCommand(ActionEvent e) {
        String command = e.getActionCommand();
        if (out != null) {
            out.println(command);
            commandList.add(command);
        }
    }

    /**
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 * # Method                :NetworkDrawClient
	 * #
	 * # Method parameters     : connectToServer
	 * #
	 * # Method return         : Yes to server.
	 * #
	 * # Synopsis              : 
	 * #   
	 * #
	 * # Modifications         :
	 * #                            Date       Developer       Notes
	 * #                            24/1/24   Dhruvit         Initial method creation.
	 * #                            
	 * #
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 */
    private void connectToServer() {
        String serverAddress = serverAddressField.getText();
        int port = Integer.parseInt(portField.getText());
        try {
            socket = new Socket(serverAddress, port);
            out = new PrintWriter(socket.getOutputStream(), true);
            new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Cannot connect to server: " + e.getMessage());
        }
    }

    /**
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 * # Method                :NetworkDrawClient
	 * #
	 * # Method parameters     : retrieveAndDraw
	 * #
	 * # Method return         : Yes to server.
	 * #
	 * # Synopsis              : 
	 * #   
	 * #
	 * # Modifications         :
	 * #                            Date       Developer       Notes
	 * #                            24/1/24   Dhruvit         Initial method creation.
	 * #                            
	 * #
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 */
    private void retrieveAndDraw() {
        out.println("DRAW");
        drawPanel.setCommands(new ArrayList<>(commandList)); // Copy of command list
        drawPanel.repaint();
    }

    /**
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 * # Method                :NetworkDrawClient
	 * #
	 * # Method parameters     : clearCommands
	 * #
	 * # Method return         : Yes to server.
	 * #
	 * # Synopsis              : 
	 * #   
	 * #
	 * # Modifications         :
	 * #                            Date       Developer       Notes
	 * #                            24/1/24   Dhruvit         Initial method creation.
	 * #                            
	 * #
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 */
    private void clearCommands() {
        out.println("CLEAR");
        commandList.clear();
        drawPanel.clear();
    }

    // Main method to start the application
    public static void main(String[] args) {
        new NetworkDrawClient();
    }

    /**
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 * # Method                :NetworkDrawClient
	 * #
	 * # Method parameters     : DrawPanel Class
	 * #
	 * # Method return         : Yes to server.
	 * #
	 * # Synopsis              : Graphic 2d used 
	 * #
	 * # Reference             : https://www.codejava.net/java-se/graphics/drawing-lines-examples-with-graphics2d  
	 * #
	 * # Modifications         :
	 * #                            Date       Developer       Notes
	 * #                            24/1/24   Dhruvit         Initial method creation.
	 * #                            
	 * #
	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	 */
    static class DrawPanel extends JPanel {
        private List<String> commands = new ArrayList<>();
        private int currentX = 150, currentY = 150;

        // Method to set new commands for drawing
        public void setCommands(List<String> commands) {//To store commands 
            this.commands = commands;
        }

        // Method to clear the drawing panel
        public void clear() {
            commands.clear();// to clear all line in drawing panel
            repaint();
        }

        /**
    	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    	 * # Method                :NetworkDrawClient
    	 * #
    	 * # Method parameters     : paintComponent Class
    	 * #
    	 * # Method return         : Yes to server.
    	 * #
    	 * # Synopsis              : Graphic 2d used 
    	 * #
    	 * # Reference             : https://www.codejava.net/java-se/graphics/drawing-lines-examples-with-graphics2d  
    	 * #
    	 * # Modifications         :
    	 * #                            Date       Developer       Notes
    	 * #                            24/1/24   Dhruvit         Initial method creation.
    	 * #                            
    	 * #
    	 * #=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    	 */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2d = (Graphics2D) g; // Cast to Graphics2D for more control
            g2d.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)); // Set stroke properties

            int lineLength = 10; // Default line length, can be set from user input
            int prevX = currentX, prevY = currentY;

            // Drawing lines based on the commands received
            for (String command : commands) {
                switch (command) {
                    case "UP RED":
                        g.setColor(Color.RED);   // UP RED when is pressed RED line will draw
                        currentY -= lineLength;
                        break;
                    case "DOWN BLUE":
                        g.setColor(Color.BLUE);// DOWN BLUE when is pressed BLUE line will draw
                        currentY += lineLength;
                        break;
                    case "LEFT GREEN":
                        g.setColor(Color.GREEN);// LEFT GREEN when is pressed GREEN line will draw
                        currentX -= lineLength;
                        break;
                    case "RIGHT YELLOW":
                        g.setColor(Color.YELLOW);// RIGHT YELLOW when is pressed YELLOW line will draw
                        currentX += lineLength;
                        break;
                }
                g.drawLine(prevX, prevY, currentX, currentY);//TO know x and y axis on drawing panel where line are drawn 
                prevX = currentX;
                prevY = currentY;
            }
        }
    }
}
