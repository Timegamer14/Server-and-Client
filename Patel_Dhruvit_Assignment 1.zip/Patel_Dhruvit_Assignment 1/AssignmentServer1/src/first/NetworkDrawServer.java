package first;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// Method                : Network Draw Server
//
// Method parameters    : startServer/handleClient/Send Command
//
// Method return        : Yes 
//
// Synopsis             :
// Modifications        :
//                            Date       Developer       Notes
//                            24/1/24     Dhruvit          
//
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
public class NetworkDrawServer {
    private static final int PORT = 12345; // Port number where the server listens
    private static List<String> commandList = new ArrayList<>(); // List to store drawing commands

    public static void main(String[] args) {
        new NetworkDrawServer().startServer(); // Start the server when the program runs
    }

  //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 // Method                : Network Draw Server
 //
 // Method parameters    : startServer
 //
 // Method return        : Yes 
 //
 // Synopsis             :
 // Modifications        :
//                             Date       Developer       Notes
//                             24/1/24     Dhruvit          
 //
 //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    private void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is listening on port " + PORT);

            // Continuously wait for client connections
            while (true) {
                try (Socket clientSocket = serverSocket.accept()) { // Accept a client connection
                    System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());
                    handleClient(clientSocket); // Handle the client's requests
                } catch (IOException e) {
                    e.printStackTrace();
                    System.out.println("Issue with a client connection.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Server failed to start.");
        }
    }

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : Network Draw Server
    //
    // Method parameters    : HandleClient
    //
    // Method return        : Yes 
    //
    // Synopsis             :
    // Modifications        :
    //                                Date       Developer       Notes
    //                                24/1/24     Dhruvit          
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    private void handleClient(Socket clientSocket) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)) {

            String inputLine;
            // Read commands sent by the client
            while ((inputLine = reader.readLine()) != null) {
                System.out.println("Received command: " + inputLine);
                switch (inputLine) {
                    case "UP RED":
                    case "DOWN BLUE":
                    case "LEFT GREEN":
                    case "RIGHT YELLOW":
                        // Add valid movement commands to the list
                        commandList.add(inputLine);
                        break;
                    case "DRAW":
                        // Send accumulated commands back to the client
                        sendCommands(writer);
                        break;
                    case "CLEAR":
                        // Clear the list of commands
                        commandList.clear();
                        break;
                    default:
                        System.out.println("Invalid command received.");
                        break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Connection with client lost.");
        }
    }

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : Network Draw Server
    //
    // Method parameters    : sendCommands
    //
    // Method return        : Yes 
    //
    // Synopsis             :
    // Modifications        :
    //                                Date       Developer       Notes
    //                                24/1/24     Dhruvit          
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=   
    private void sendCommands(PrintWriter writer) {
        String commands = String.join(",", commandList);
        writer.println(commands); // Send the concatenated commands
    }
}
